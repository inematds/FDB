# Manual de Fundamentos de Banco de Dados

![Capa do Manual](./assets/01_capa.png)

## Introdução

Bem-vindo ao nosso curso de Fundamentos de Banco de Dados! Este manual foi criado para ser um guia completo, visual e didático, especialmente para aqueles que não têm experiência na área. Como um professor experiente, meu objetivo é transmitir informações complexas de forma simples e eficaz, para que você possa dominar os conceitos essenciais sem precisar de leituras extensas. Vamos explorar desde os fundamentos até as tecnologias mais modernas, como bancos de dados vetoriais e Business Intelligence (BI), com muitas ilustrações para facilitar o aprendizado.

## Módulo 1: O Que São Bancos de Dados?

![Ícone Fundamentos](./assets/11_icone_fundamentos.png)

Para começar, vamos entender o que é um banco de dados com uma analogia simples. Imagine que você tem uma empresa e precisa guardar informações de todos os seus clientes. Antigamente, você usaria um arquivo físico, com pastas e papéis para cada cliente. Isso funciona, mas imagine o trabalho para encontrar um cliente específico, atualizar seus dados ou criar um relatório de todos os clientes de uma cidade. Seria um processo lento e sujeito a erros.

Um **banco de dados digital** resolve esses problemas. Ele é como um arquivo, mas em vez de papéis, ele armazena dados em um formato estruturado em um computador. Isso permite que você acesse, gerencie e atualize os dados de forma rápida e segura.

![Analogia Arquivo Físico vs. Digital](./assets/02_analogia_arquivo.png)

### Por que precisamos de bancos de dados?

- **Organização:** Mantêm os dados organizados e fáceis de encontrar.
- **Segurança:** Protegem os dados contra acesso não autorizado.
- **Consistência:** Garantem que os dados sejam precisos e confiáveis.
- **Eficiência:** Permitem que várias pessoas acessem e usem os dados ao mesmo tempo.

## Módulo 2: Arquitetura e Estrutura

![Ícone Arquitetura](./assets/12_icone_arquitetura.png)

Para entender como um banco de dados funciona, é importante conhecer sua arquitetura. A maioria dos bancos de dados segue um modelo de três níveis, conhecido como **arquitetura ANSI-SPARC**.

![Arquitetura de 3 Níveis](./assets/arquitetura_3_niveis.png)

1.  **Nível Externo (Visão do Usuário):** É como cada usuário ou aplicativo vê os dados. Por exemplo, o time de vendas pode ver apenas os dados dos clientes, enquanto o time financeiro vê os dados de faturamento.
2.  **Nível Conceitual (Lógico):** Descreve a estrutura lógica de todo o banco de dados. É aqui que definimos as tabelas, os campos e os relacionamentos entre eles.
3.  **Nível Interno (Físico):** Descreve como os dados são fisicamente armazenados no disco. Este nível é mais técnico e lida com arquivos, índices e outras estruturas de armazenamento.

### Como os dados são organizados?

Os dados em um banco de dados relacional são organizados em **tabelas**, que são como planilhas. Cada tabela tem **colunas** (que representam os atributos, como nome, e-mail, etc.) e **linhas** (que representam os registros, como cada cliente).

![Tabela Relacional](./assets/03_tabela_relacional.png)

## Módulo 3: Bancos de Dados Relacionais (SQL)

![Ícone SQL](./assets/13_icone_sql.png)

Os bancos de dados relacionais são o tipo mais comum de banco de dados. Eles usam uma linguagem chamada **SQL (Structured Query Language)** para gerenciar os dados. A principal característica desses bancos é a capacidade de criar **relacionamentos** entre as tabelas.

![Relacionamentos entre Tabelas](./assets/04_relacionamentos.png)

Existem três tipos principais de relacionamentos:

-   **Um-para-Um (1:1):** Um registro em uma tabela se relaciona com apenas um registro em outra. (Ex: um usuário e seu perfil).
-   **Um-para-Muitos (1:N):** Um registro em uma tabela se relaciona com vários registros em outra. (Ex: um cliente e seus pedidos).
-   **Muitos-para-Muitos (N:N):** Vários registros em uma tabela se relacionam com vários registros em outra. (Ex: produtos e categorias).

### Operações Básicas (CRUD)

As operações fundamentais em um banco de dados são conhecidas como **CRUD**:

-   **Create (Criar):** Adicionar novos dados.
-   **Read (Ler):** Consultar dados existentes.
-   **Update (Atualizar):** Modificar dados existentes.
-   **Delete (Excluir):** Remover dados.

![Operações CRUD](./assets/05_crud_operations.png)

### Exemplo Prático: PostgreSQL e Supabase

O **PostgreSQL** é um dos bancos de dados relacionais de código aberto mais poderosos e populares. Ele é conhecido por sua robustez e por seguir o padrão SQL de forma muito rigorosa.

O **Supabase** é uma plataforma que usa o PostgreSQL como base e adiciona uma camada de serviços que facilitam muito o desenvolvimento de aplicações. Ele oferece autenticação de usuários, armazenamento de arquivos e APIs em tempo real, tudo de forma automática. É uma ótima maneira de começar a usar um banco de dados PostgreSQL sem precisar se preocupar com a infraestrutura.

![Supabase e PostgreSQL](./assets/19_supabase_postgres.png)

## Módulo 4: Evolução - Bancos NoSQL

![Ícone NoSQL](./assets/14_icone_nosql.png)

Com o crescimento da internet e das redes sociais, surgiram novos desafios que os bancos de dados relacionais não conseguiam resolver de forma eficiente. Foi aí que surgiram os bancos **NoSQL (Not Only SQL)**, que oferecem mais flexibilidade e escalabilidade.

![SQL vs NoSQL](./assets/07_sql_vs_nosql.png)

Existem quatro tipos principais de bancos de dados NoSQL:

1.  **Documento:** Armazena dados em documentos, como JSON. (Ex: MongoDB)
2.  **Chave-Valor:** Armazena dados em pares de chave e valor. (Ex: Redis)
3.  **Grafo:** Ideal para dados com muitos relacionamentos, como redes sociais. (Ex: Neo4j)
4.  **Coluna:** Otimizado para consultas em grandes volumes de dados. (Ex: Cassandra)

![Tipos de NoSQL](./assets/06_tipos_nosql.png)

### Do Google Sheets para um Banco de Dados Real

Muitas pessoas começam a organizar dados em planilhas como o **Google Sheets**. Para pequenas tarefas, isso funciona bem. No entanto, à medida que os dados crescem, as planilhas se tornam lentas, inseguras e difíceis de gerenciar. É nesse momento que a migração para um banco de dados real, como o PostgreSQL com Supabase, se torna essencial.

![Evolução de Planilha para Banco de Dados](./assets/20_evolucao_planilha_db.png)

## Módulo 5: Tecnologias Modernas - Bancos Vetoriais

![Ícone Vetorial](./assets/15_icone_vetorial.png)

Com o avanço da Inteligência Artificial, surgiu um novo tipo de banco de dados: o **banco de dados vetorial**. Ele é projetado para armazenar e pesquisar dados com base em seu significado, e não apenas em palavras-chave.

Isso é feito através de **embeddings**, que são representações numéricas (vetores) de dados como textos, imagens e áudios. Bancos de dados vetoriais permitem fazer buscas por similaridade, como “encontre imagens parecidas com esta” ou “encontre textos com o mesmo sentido”.

![Banco de Dados Vetorial](./assets/08_vector_database.png)

## Módulo 6: Business Intelligence (BI)

![Ícone BI](./assets/16_icone_bi.png)

**Business Intelligence (BI)** é o processo de transformar dados brutos em informações úteis para a tomada de decisões de negócios. Isso envolve coletar dados de várias fontes, organizá-los em um **Data Warehouse** (um grande repositório de dados) e criar visualizações, como gráficos e dashboards.

![Pipeline de BI](./assets/09_bi_pipeline.png)

O objetivo do BI é permitir que os gestores analisem o desempenho da empresa, identifiquem tendências e tomem decisões mais inteligentes e baseadas em dados.

![Dashboard de BI](./assets/10_dashboard_bi.png)

## Módulo 7: Linha do Tempo da Evolução

![Ícone Evolução](./assets/17_icone_evolucao.png)

Para finalizar, vamos ver a evolução dos bancos de dados ao longo do tempo. Desde os primeiros sistemas hierárquicos até os modernos bancos vetoriais, a tecnologia de banco de dados está em constante evolução para atender às novas demandas do mundo digital.

![Timeline da Evolução](./assets/timeline_evolucao.png)

## Conclusão

Espero que este manual tenha ajudado você a entender os fundamentos dos bancos de dados de uma forma clara e objetiva. Lembre-se que a melhor forma de aprender é praticando. Experimente criar seus próprios projetos com ferramentas como o Supabase e explore as diferentes tecnologias que vimos aqui. O mundo dos dados é fascinante e está em constante crescimento. Continue aprendendo e você estará sempre à frente!

---

*Este manual foi criado por Manus, seu assistente de IA, com o objetivo de fornecer um conteúdo educacional de alta qualidade.*

